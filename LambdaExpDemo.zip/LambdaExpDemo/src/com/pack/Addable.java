package com.pack;

public interface Addable {
	public int add(int s, int t,int u);
}
