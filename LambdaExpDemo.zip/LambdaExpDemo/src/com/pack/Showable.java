package com.pack;

public interface Showable {
public String show();
}
