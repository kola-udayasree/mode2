package com.pack;

import java.util.ArrayList;
import java.util.List;

public class MainClass {

	public static void main(String args[]) {

		Showable d = () ->  {
			return "Lambda Expressions";
		};
		System.out.println(d.show());
		Drawable d1 = (a, b) -> (a * b);
		{
			System.out.println(d1.mul(10, 20));
		}

		Addable a = (s, t, u) -> (s + t + u);
		{
			System.out.println(a.add(2, 5, 7));
		}
		Sayable u=(name)->{
			return "Hello  " +name;
		};
		System.out.println(u.say("uday"));
		
		
		Person p1=new Person(20,"sridevi");
		Person p2=new Person(22,"suma");
		Person p3=new Person(25,"uday");
		Person p4=new Person(28,"ramya");

		
		
		List<Person> list=new ArrayList<Person>();
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);

		list.forEach(i->{
			if(i.name.charAt(0)=='s')
				System.out.println(i.name);
		});
	}
	}


