package com.pack;
@FunctionalInterface
public interface Drawable {
 /* public String show();*/
 
  public int mul(int a,int b);
 
}
