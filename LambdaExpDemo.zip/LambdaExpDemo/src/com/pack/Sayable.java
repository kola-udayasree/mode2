package com.pack;

public interface Sayable {
public String say(String name);
}
