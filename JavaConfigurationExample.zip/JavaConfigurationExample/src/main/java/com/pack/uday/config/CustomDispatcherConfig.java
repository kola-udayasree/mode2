package com.pack.uday.config;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.pack.uday.beans.UserBean;


	@EnableWebMvc
	@Configuration
	@ComponentScan(basePackages="com.pack.uday")

public class CustomDispatcherConfig extends WebMvcConfigurerAdapter {
		public static final String ENCODING_UTF = "UTF";

	    public static final String ENCODING_UTF_8 = "UTF-8";

	    public static final long MAX_UPLOAD_FILE_SIZE = 52428807;

	    public static final long MAX_UPLOAD_PER_FILE_SIZE = 5242880;

	    
	    @Bean
	    public InternalResourceViewResolver getJspViewResolver() {

	        InternalResourceViewResolver ret = new InternalResourceViewResolver();

	        ret.setPrefix("/WEB-INF/views/");

	        ret.setSuffix(".jsp");

	        ret.setOrder(1);

	        return ret;

	    }


	 
	    @Bean(name = "messageSource")
	    public MessageSource getMessageSource() {
	        ReloadableResourceBundleMessageSource ret = new ReloadableResourceBundleMessageSource();

	        ret.setBasename("classpath:config/message_en_US");

	        ret.setCacheSeconds(1);

	        ret.setUseCodeAsDefaultMessage(true);

	        ret.setDefaultEncoding(ENCODING_UTF);

	        return ret;
	    }

	    /* Register the UserAccountbean. */
	    @Bean(name = "userBean")
	    public UserBean getUserBean() {
	        UserBean ret = new UserBean();
	        return ret;
	    }

	}



