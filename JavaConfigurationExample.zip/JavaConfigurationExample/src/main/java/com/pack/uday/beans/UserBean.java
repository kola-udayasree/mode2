package com.pack.uday.beans;



public class UserBean{
	 public boolean checkUserLogin(String userName, String password)
	    {
	        boolean ret = false;

	        if("Uday".equalsIgnoreCase(userName) && "bepositive".equals(password))
	        {
	            ret = true;
	        }
	        return ret;
	    }}