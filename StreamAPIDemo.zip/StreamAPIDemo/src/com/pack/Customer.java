package com.pack;

import javax.validation.constraints.NotNull;

public class Customer {
	@NotNull
	String name;
	int age;
	Long phoneNum;
	String accNum=null;
	float amount;
	float balance;
	float rembal;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Long getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(Long phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getAccNum() {
		return accNum;
	}
	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public float getRembal() {
		return rembal;
	}
	public void setRembal(float rembal) {
		this.rembal = rembal;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
		
		
	}
	public Customer(String name, int age, Long phoneNum, String accNum, float amount, float rembal) {
		super();
		this.name = name;
		this.age = age;
		this.phoneNum = phoneNum;
		this.accNum = accNum;
		this.amount = amount;
		
		this.rembal=rembal;
	}
	public float withdraw(float amount, float balance) {
		// TODO Auto-generated method stub
		float s;
		return s=balance-amount;
	}}
	
	
