package com.pack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SBIExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> acc = new ArrayList<Integer>();
		System.out.println("Enter account Numbers");
		Scanner sn = new Scanner(System.in);
		for (int i = 0; i < 1; i++) {
			int a = sn.nextInt();
			acc.add(a);
		}
		Customer[] c = new Customer[20];

		List<String> Acc = acc.stream().map(i -> "SBI" + i).collect(Collectors.toList());
		List<String> ValidAcc = Acc.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
		List<String> InValidAcc = Acc.stream().filter(i -> i.length() != 8).collect(Collectors.toList());

		System.out.println("Valid accounts are: " + ValidAcc.size());
		System.out.println("InValid accounts are: " + InValidAcc.size());
		List<Customer> cust = new ArrayList<>();
		String name;
		int age;
		Long phoneNum;
		String accNum=null;
		float amount;
		float balance;
		
		
		for(int i=0;i<ValidAcc.size();i++){
			System.out.println("Enter name");
			name=sn.next();
			System.out.println("Enter age");
			age=sn.nextInt();
			System.out.println("Enter phone number");
			phoneNum=sn.nextLong();
			System.out.println("Enter total balance");
			balance=sn.nextFloat();
			System.out.println("Enter the amount to be withdrawn");
			amount=sn.nextFloat();
			
			accNum=ValidAcc.get(i);
			Customer x=new Customer();
			float rembal=x.withdraw(amount,balance);
			c[i]=new Customer(name,age,phoneNum,accNum,amount,rembal);
			cust.add(c[i]);
		}
		List<Customer> v=cust.stream()
		 .filter(x->((x.name.matches("[A-Z][a-z].*"))&&(x.age>=18)&&(String.valueOf(x.phoneNum).matches("[0-9].*")&&(String.valueOf(x.phoneNum).length()==10))))
		 .collect(Collectors.toList());		
		List<Customer> sort=v.stream().sorted(Comparator.comparing(Customer::getName))
				.collect(Collectors.toList());
		sort.forEach((temp)->{
			System.out.println(temp.accNum +" is valid");
			
			System.out.println(temp.name +" "+temp.age+" "+temp.phoneNum+" "+temp.accNum+" "+temp.amount+" "+temp.rembal);
			System.out.println("your Remaining Balance is: "+temp.rembal);
		});
		List<Customer> i=cust.stream()
				 .filter(x->!((x.name.matches("[A-Z][a-z].*"))&&(x.age>=18)&&(String.valueOf(x.phoneNum).matches("[0-9].*"))))
				 .collect(Collectors.toList());	
		i.forEach((temp)->{
			System.out.println(temp.accNum +" is invalid");
			System.out.println("Your Credentials are wrong!!!!");
			/*if(temp.balance<temp.amount){
				System.out.println("You balance is insufficient");*/
			
});
		
	}
}
