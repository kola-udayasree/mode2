package com.pack;

import java.util.Arrays;
import java.util.List;

public class Example1 {
	public static void main(String args[]) {
		List<Integer> myList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		myList
		.stream()
		.filter(num -> num % 2 == 0)
		
		.forEach(System.out::println);
	}
}
