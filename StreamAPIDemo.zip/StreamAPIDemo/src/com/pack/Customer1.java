package com.pack;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


@Repeatable(Customers.class)

public @interface Customer1 {
	
	String name();
	int age();
	String phoneNum();
	//String accNum=null();
	float amount();
	float balance();
	//float rembal();
	
}
@Retention(RetentionPolicy.RUNTIME)

 @interface Customers{
	Customer1[] value();
	}
