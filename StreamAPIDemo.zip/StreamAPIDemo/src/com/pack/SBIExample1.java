package com.pack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Customer1(name = "Uday", age = 22,phoneNum="6473567346",balance=100000,amount=50000)
@Customer1(name = "Ramya", age = 20,phoneNum="6423567346",balance=200000,amount=100000)


public class SBIExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> acc = new ArrayList<Integer>();
		List<String> Acc = acc.stream().map(i -> "SBI" + i).collect(Collectors.toList());
		//List<String> ValidAcc = Acc.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
	//	List<String> InValidAcc = Acc.stream().filter(i -> i.length() != 8).collect(Collectors.toList());
		
		Customer[] c = new Customer[20];

		Customer1[] cust = SBIExample1.class.getAnnotationsByType(Customer1.class);
		List<Customer1> customer=new ArrayList<Customer1>();
		for(Customer1 cust2 :cust){
			customer.add(cust2);
		System.out.println(cust2.name()+" "+cust2.age()+" "+cust2.phoneNum()+" "+cust2.balance()+" "+cust2.amount());
	}

}}
