package com.calculator.service;

import java.rmi.RemoteException;

public class TestClass {
public static void main(String args[]){
	try{
	CalculatorServiceStub stub=new CalculatorServiceStub();
	CalculatorServiceStub.Addition params=new CalculatorServiceStub.Addition();
	params.setA(40);
	params.setB(50);
	CalculatorServiceStub.AdditionResponse response=stub.addition(params);
	int result= response.get_return();
	System.out.println("Result is: "+result);}
	catch(RemoteException e){
		e.printStackTrace();
	}
	try{
		CalculatorServiceStub stub=new CalculatorServiceStub();
		CalculatorServiceStub.Subtraction params=new CalculatorServiceStub.Subtraction();
		params.setA(90);
		params.setB(50);
		CalculatorServiceStub.SubtractionResponse response=stub.subtraction(params);
		int result= response.get_return();
		System.out.println("Result is: "+result);}
		catch(RemoteException e){
			e.printStackTrace();
		}
	try{
		CalculatorServiceStub stub=new CalculatorServiceStub();
		CalculatorServiceStub.Multiplication params=new CalculatorServiceStub.Multiplication();
		params.setA(9);
		params.setB(5);
		CalculatorServiceStub.MultiplicationResponse response=stub.multiplication(params);
		int result= response.get_return();
		System.out.println("Result is: "+result);}
		catch(RemoteException e){
			e.printStackTrace();
		}
	try{
		CalculatorServiceStub stub=new CalculatorServiceStub();
		CalculatorServiceStub.Division params=new CalculatorServiceStub.Division();
		params.setA(100);
		params.setB(5);
		CalculatorServiceStub.DivisionResponse response=stub.division(params);
		int result= response.get_return();
		System.out.println("Result is: "+result);}
		catch(RemoteException e){
			e.printStackTrace();
		}
}
}
